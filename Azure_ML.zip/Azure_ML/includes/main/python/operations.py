# Databricks notebook source
def split(data, feat, target):
    """Select train and test datasets"""
    
    data_na = data[feat + target].dropna(how='any')
    
    # set up target as y
    y = data_na[target[0]].values
    
    # features for model as X
    X = data_na.drop(labels=[target[0]], axis=1)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=101)
    
    return {"X_train": X_train, "y_train":y_train, "X_test":X_test, "y_test":y_test}

# COMMAND ----------

def plot_hist_split(data, target, y_train, y_test):
    import seaborn as sns
    import matplotlib.pyplot as plt
    """ Plotting data split """

    # Plotting
    fig, (ax1, ax3, ax5) = plt.subplots(1,3,figsize=(30,10))
    fig.tight_layout(pad=8.0)

    ax2 = ax1.twinx()
    n, bins, patches = ax1.hist(pd.Series(y_train), bins=100)
    n, bins, patches = ax2.hist(pd.Series(y_train), cumulative=1, histtype='step', density =True, bins=100, color='orange')
    ax2.set_title("Train",fontsize=15)
    poly = ax2.findobj(plt.Polygon)[0]
    vertices = poly.get_path().vertices

    # Keep everything above y == 0. You can define this mask however
    # you need, if you want to be more careful in your selection.
    keep = vertices[:, 1] > 0

    # Construct new polygon from these "good" vertices
    new_poly = plt.Polygon(vertices[keep], closed=False, fill=False,
                 edgecolor=poly.get_edgecolor(),
                 linewidth=poly.get_linewidth())
    poly.set_visible(False)
    ax2.add_artist(new_poly)


    ax4 = ax3.twinx()
    n, bins, patches = ax3.hist(pd.Series(y_test), bins=100)
    n, bins, patches = ax4.hist(pd.Series(y_test), cumulative=1, histtype='step', density =True, bins=100, color='orange')
    ax4.set_title("Test", fontsize=15)
    poly = ax4.findobj(plt.Polygon)[0]
    vertices = poly.get_path().vertices

    # Keep everything above y == 0. You can define this mask however
    # you need, if you want to be more careful in your selection.
    keep = vertices[:, 1] > 0

    # Construct new polygon from these "good" vertices
    new_poly = plt.Polygon(vertices[keep], closed=False, fill=False,
                 edgecolor=poly.get_edgecolor(),
                 linewidth=poly.get_linewidth())
    poly.set_visible(False)
    ax4.add_artist(new_poly)
    
    # Full dataset
    ax6 = ax5.twinx()
    n, bins, patches = ax5.hist(pd.Series(data[target[0]]), bins=100)
    n, bins, patches = ax6.hist(pd.Series(data[target[0]]), cumulative=1, histtype='step', density =True, bins=100, color='orange')
    ax6.set_title("Full Dataset",fontsize=15)
    poly = ax6.findobj(plt.Polygon)[0]
    vertices = poly.get_path().vertices
    # Keep everything above y == 0. You can define this mask however
    # you need, if you want to be more careful in your selection.
    keep = vertices[:, 1] > 0

    # Construct new polygon from these "good" vertices
    new_poly = plt.Polygon(vertices[keep], closed=False, fill=False,
         edgecolor=poly.get_edgecolor(),
         linewidth=poly.get_linewidth())
    poly.set_visible(False)
    ax6.add_artist(new_poly)

    plt.show();

# COMMAND ----------

def target_predict(model, target, X_train, y_train, X_test, y_test):
    """Fit models, calculate score and plot predicted vs measured"""
    
    # Scale features as their orders of magnitude are significantly different
    scaler = StandardScaler()
    scaler.fit(X_train)
    X_train_scaled = scaler.transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train the model
    model.fit(X_train_scaled, y_train)
    
    # Make Predicitons
    y_pred = model.predict(X_test_scaled)
    
    # Predict in test set
    df_test = {
    'test_pred': model.predict(X_test),
    'test_meas': y_test
    }
    
    df_pred = pd.DataFrame(df_test)
    
    # Residuals
    df_test['residuals'] = df_test['test_meas'] - df_test['test_pred']
    
     
    # Metrics - Score the Regressor Model
    r2 = model.score(X_train_scaled, y_train).round(2) 
    RMSE = mean_squared_error(y_test, y_pred).round(2)
    MAE = mean_absolute_error(y_test, y_pred).round(2)
    RE = mean_absolute_percentage_error(y_test, y_pred).round(2)

    print('Metrics: ','r2:',r2,' MAE: $',MAE,' MAE: %',RE*100)
    
    # Retrive info on the feature contributions and print them in order of importance
    feature_list = list(X_train.columns)
    feature_imp = pd.Series(model.feature_importances_, index=feature_list).sort_values(ascending=False)
    
    return {'y_pred': y_pred, 'df_pred': df_pred, 'feature_imp': feature_imp}

# COMMAND ----------

def plot_predictions (df_pred, target):
    """ Plotting Predictions """

    f, axes = plt.subplots(1,2, figsize=(20,10))
    f.tight_layout(pad=8.0)

    # Plot Pred vs Measured Test
    slope, intercept, r_value, p_value, std_err = stats.linregress(
    df_pred['test_pred'], df_pred['test_meas'])

    r_2 = r_value**2
    eqn = "R2 = {}".format(r_2.round(2))

    mape_test = mean_absolute_percentage_error(df_pred['test_meas'], df_pred['test_pred'])*100 
    eqn_mape = "error = {}%".format(mape_test.round(1))

    plt.figure(figsize=(5,5))
    sns.regplot(data=df_pred,
        x='test_pred',
        y='test_meas',
        fit_reg=True,
        line_kws={'color': 'red'},
         ax=axes[0])

    #xmin = df_pred['test_pred'].min()
    #ymin = df_pred['test_meas'].min()
    xmax = df_pred['test_pred'].max()
    ymax = df_pred['test_meas'].max()

    # axes[0].plot([0,ymax], [0,ymax], '--',color='black',linewidth=3)
    axes[0].axis(xmin=0,xmax=ymax)# used ymax for both otherwise plot looks weird
    axes[0].axis(ymin=0,ymax=ymax)

    axes[0].set_xlabel('{}_Predicted'.format(target[0]),weight='bold', fontsize=15)
    axes[0].set_ylabel('{}_Measured'.format(target[0]),weight='bold', fontsize=15)

    axes[0].text(0.75, 0.2, "{}\n{}".format(eqn,eqn_mape), horizontalalignment='center', verticalalignment='center', transform=axes[0].transAxes, fontsize=12)
    
    # Residuals
    df_pred['residuals'] = df_pred['test_meas'] - df_pred['test_pred']
    sns.distplot(df_pred['residuals'],ax=axes[1]).set_title('Residuals_Test', weight='bold', fontsize=15)
    axes[1].set_xlabel('Residuals', weight='bold', fontsize=15)

    plt.show();

# COMMAND ----------

