# Databricks notebook source
# MAGIC %md
# MAGIC # Set Up

# COMMAND ----------

# MAGIC %run ./includes/configuration

# COMMAND ----------

# MAGIC %run ./includes/main/python/operations

# COMMAND ----------

# MAGIC %md
# MAGIC # Load Data

# COMMAND ----------

# Using pyspark to access the data

dataPath = "/FileStore/tables/avocado.csv"

dataDF = (spark.read
  .option("sep", ",")
  .option("header", True)
  .option("inferSchema", True)
  .csv(dataPath))

dataDF.printSchema()

# COMMAND ----------

display(dataDF)

# COMMAND ----------

# MAGIC %md
# MAGIC # Paramerter Definition

# COMMAND ----------

# MAGIC %md
# MAGIC ## Feature Selection

# COMMAND ----------

feat_sel = ['Total Volume', 'type', 'year', 'region']
target_sel = ['AveragePrice']

# COMMAND ----------

# MAGIC %md
# MAGIC ## Model Definition

# COMMAND ----------

# base RF regressor model
model = RandomForestRegressor(random_state=101)

# COMMAND ----------

# MAGIC %md
# MAGIC ## DataFrame Build

# COMMAND ----------

df_pyspark = dataDF.select(feat_sel + target_sel)
display(df_pyspark)

# COMMAND ----------

# Moving into pandas language for modeling part of this demo
df = df_pyspark.toPandas()

# COMMAND ----------

# Label encode region and type categorical features
df['region'] = df['region'].astype('category').cat.codes
df['type'] = df['type'].astype('category').cat.codes

# COMMAND ----------

# MAGIC %md
# MAGIC # EDA

# COMMAND ----------

# MAGIC %md
# MAGIC Are there any relationships that jump out at us from these selected features? Looks like there is some clustering happening with AveragePrice and TotalVolume; what could that be from?

# COMMAND ----------

sns.pairplot(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Checking correlations between features before running the model; best practice is to not carry forward highly correlated features. If you run this code with df_orig instead, you will see I have dropped those in my feature selection above

# COMMAND ----------

sns.set(font_scale=1.8)
sns.set_style("whitegrid") 
plt.figure(figsize=(25,10))
cor = df.drop('AveragePrice',axis=1).corr().abs() # try df_orig instead
dropvals = np.zeros_like(cor)
dropvals[np.triu_indices_from(dropvals)] = True
colormap = sns.diverging_palette(220, 10, as_cmap = True)
sns.heatmap(cor, cmap = colormap, linewidths = .5, annot = True, fmt = ".2f", mask = dropvals,vmin=0.0,vmax=1.0)
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC # Data Set Up

# COMMAND ----------

data_split = split(df, feat_sel, target_sel)
plot_hist_split(df, target_sel, data_split['y_train'], data_split['y_test'])

# COMMAND ----------

# MAGIC %md
# MAGIC # Run Model and Obtain Score

# COMMAND ----------

rf_model =  target_predict(model, target_sel, data_split["X_train"], data_split["y_train"], data_split["X_test"], data_split["y_test"])

# COMMAND ----------

# MAGIC %md
# MAGIC # Plot Results

# COMMAND ----------

# MAGIC %md
# MAGIC Please note how this model is predicting the values in bands below; this is out of scope for the purposes of this notebook but please know that this is a bad result, and needs to be optimized!

# COMMAND ----------

plot_predictions(rf_model['df_pred'], target_sel)

# COMMAND ----------

# MAGIC %md
# MAGIC What are the most important features in this RandomForestRegressor? Could we remove some that aren't important? 

# COMMAND ----------

# Retrive info on the feature contributions and print them in order of importance
ax = sns.barplot(x=rf_model['feature_imp'], y=rf_model['feature_imp'].index)
plt.title("Vizualizing Important Features", weight='bold', fontsize=15)
plt.xlabel('Feature Importance Score')

# COMMAND ----------

# MAGIC %md
# MAGIC This notebook shows a simple demo for regression; now let's apply this workflow to Azure Machine Learning Design Studio

# COMMAND ----------

